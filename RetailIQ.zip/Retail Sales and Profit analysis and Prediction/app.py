import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

# Set page config
st.set_page_config(page_title="Big Mart Sales Dashboard", layout="wide")

# Load data (using your processed training data)
@st.cache_data
def load_data():
    df = pd.read_csv('Train-Set.csv')
    df['FatContent'] = df['FatContent'].replace({'LF':'Low Fat', 'reg':'Regular', 'low fat':'Low Fat'})
    return df

df = load_data()

# --- SIDEBAR FILTERS ---
st.sidebar.header("Dashboard Filters")
outlet_type = st.sidebar.multiselect("Select Outlet Type", options=df['OutletType'].unique(), default=df['OutletType'].unique())
filtered_df = df[df['OutletType'].isin(outlet_type)]

# --- MAIN HEADER ---
st.title("📊 Big Mart Sales Analysis Dashboard")
st.markdown("Insights into product performance and outlet sales efficiency.")

# --- ROW 1: KEY METRICS ---
col1, col2, col3, col4 = st.columns(4)
col1.metric("Total Sales", f"${filtered_df['OutletSales'].sum():,.0f}")
col2.metric("Avg MRP", f"${filtered_df['MRP'].mean():.2f}")
col3.metric("Total Items", len(filtered_df))
col4.metric("Avg Visibility", f"{filtered_df['ProductVisibility'].mean()*100:.2f}%")

st.divider()

# --- ROW 2: VISUAL ANALYTICS ---
c1, c2 = st.columns(2)

with c1:
    st.subheader("Sales by Product Type")
    fig_sales = px.bar(filtered_df.groupby('ProductType')['OutletSales'].sum().reset_index(), 
                       x='ProductType', y='OutletSales', color='OutletSales',
                       color_continuous_scale='Viridis')
    st.plotly_chart(fig_sales, use_container_width=True)

with c2:
    st.subheader("MRP vs. Outlet Sales")
    fig_scatter = px.scatter(filtered_df.sample(1000), x='MRP', y='OutletSales', 
                             color='OutletType', opacity=0.6,
                             title="Correlation check (Sampled Data)")
    st.plotly_chart(fig_scatter, use_container_width=True)

# --- ROW 3: OUTLET PERFORMANCE ---
st.subheader("Outlet Performance Comparison")
fig_box = px.box(filtered_df, x='OutletType', y='OutletSales', color='OutletSize')
st.plotly_chart(fig_box, use_container_width=True)

# --- INTERACTIVE PREDICTION SECTION ---
st.divider()
st.header("🔮 Sales Predictor")
st.info("Enter product details below to estimate potential sales.")

pi1, pi2, pi3 = st.columns(3)
with pi1:
    mrp_input = st.number_input("Maximum Retail Price (MRP)", value=150.0)
    visibility_input = st.slider("Product Visibility", 0.0, 0.35, 0.06)
with pi2:
    weight_input = st.number_input("Item Weight", value=12.0)
    outlet_input = st.selectbox("Outlet Type", df['OutletType'].unique())
with pi3:
    fat_input = st.selectbox("Fat Content", ["Low Fat", "Regular"])

# Simplified prediction logic (for display purposes)
# In a real app, you would load your saved .pkl model here
estimated_sales = (mrp_input * 12.5) + (visibility_input * -100) 
st.success(f"### Estimated Potential Sales: **${estimated_sales:,.2f}**")